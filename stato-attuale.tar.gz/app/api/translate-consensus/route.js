import { NextResponse } from 'next/server';
import { withApiGuard } from '../../lib/apiGuard.js';
import { redis } from '../../lib/redis.js';
import { tryProvider, getProviderChain, validateTranslation, scoreTranslation } from '../../lib/providers.js';
import { findConsensus } from '../../lib/consensus.js';
import { createLogger } from '../../lib/logger.js';
import { assertElaborazioneConsentita, DirectModeError } from '../../lib/sessionGuard.js';
import { getSimpleHash } from '../../lib/translateValidation.js';

const log = createLogger('translateConsensus');

// b.168 — vedi la stessa nota in translate-free/route.js: l'email va
// verificata da una sessione, non dichiarata dal client.
async function emailVerificata(userToken) {
  if (!userToken || typeof userToken !== 'string') return null;
  try {
    const { getSession } = await import('../../lib/users.js');
    const sessione = await getSession(userToken);
    return sessione?.email || null;
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════════════
// Consensus Translation — "Guaranteed" mode
//
// Calls top providers for the target language in parallel,
// compares results using Levenshtein similarity.
// If 2 agree → "guaranteed" translation
//
// Security: rate limited 20 req/min, CORS restricted
// ═══════════════════════════════════════════════

// b.111 — c'erano tre copie della stessa impronta rotta, una per
// rotta. Ora e una sola, e funziona (vedi translateValidation.js).

const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || process.env.NEXT_PUBLIC_URL || 'https://voice-translator2.vercel.app';

function getCorsHeaders(req) {
  const origin = req?.headers?.get?.('origin') || '';
  const allowed = origin === ALLOWED_ORIGIN
    || origin.startsWith('http://localhost')
    || origin.startsWith('https://localhost');
  return {
    'Access-Control-Allow-Origin': allowed ? origin : ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

export async function OPTIONS(req) {
  return new NextResponse(null, { status: 204, headers: getCorsHeaders(req) });
}

async function handlePost(req) {
  const cors = getCorsHeaders(req);

  try {
    const { text, sourceLang, targetLang, threshold, roomId, roomSessionToken, userToken } = await req.json();
    // b.168 — non piu il valore dichiarato dal body: vedi emailVerificata sopra.
    const userEmail = await emailVerificata(userToken);

    // ── Direct mode guard ──
    // b.167 — CONFERMATO (audit esterno 15/8): come translate-free, si
    // fidava solo dell'intestazione.
    try {
      await assertElaborazioneConsentita(req, { roomId, roomSessionToken });
    } catch (e) {
      if (e instanceof DirectModeError) return NextResponse.json({ error: e.message }, { status: 403 });
      throw e;
    }

    if (!text?.trim()) {
      return NextResponse.json({ translated: '', guaranteed: false }, { headers: cors });
    }

    const trimmed = text.trim();
    const charsUsed = trimmed.length;

    // ── Check cache first ──
    const textHash = getSimpleHash(trimmed);
    const cacheKey = `tcc:${sourceLang}:${targetLang}:${textHash}`;
    try {
      const cached = await redis('GET', cacheKey);
      if (cached) {
        let parsed; try { parsed = JSON.parse(cached); } catch { parsed = null; }
        if (parsed && parsed.translated && parsed.guaranteed) {
          return NextResponse.json({ ...parsed, cached: true }, { headers: cors });
        }
      }
    } catch (e) { log.warn('Cache JSON parse error:', e?.message); }

    // ── Get top 3 providers for this language ──
    const chain = getProviderChain(targetLang);
    const top3 = chain.slice(0, 3);

    // ── Call all 3 in parallel ──
    const results = await Promise.allSettled(
      top3.map(id => tryProvider(id, trimmed, sourceLang, targetLang, userEmail))
    );

    // ── Validate and score results ──
    const validResults = [];
    for (let i = 0; i < results.length; i++) {
      if (results[i].status === 'fulfilled') {
        const r = results[i].value;
        if (r.text) {
          const validation = validateTranslation(trimmed, r.text, sourceLang, targetLang);
          const scoring = scoreTranslation(trimmed, r.text, sourceLang, targetLang, r.provider);
          if (validation.valid) {
            validResults.push({
              text: r.text,
              provider: r.provider,
              score: scoring.score,
              elapsed: r.elapsed,
            });
          }
        }
      }
    }

    // ── Find consensus ──
    const consensus = findConsensus(validResults, threshold || 0.75);

    const response = {
      translated: consensus.text || trimmed,
      guaranteed: consensus.guaranteed,
      confidence: consensus.confidence,
      providers: consensus.agreedProviders,
      provider: 'consensus',
      charsUsed,
      fallback: !consensus.text,
    };

    // ── Cache guaranteed results for 24h ──
    if (consensus.guaranteed) {
      try {
        await redis('SET', cacheKey, JSON.stringify(response), 'EX', 86400);
      } catch (e) { log.warn('Cache set failed:', e?.message); }
    }

    return NextResponse.json(response, { headers: cors });
  } catch (e) {
    log.error('Consensus translate error:', e);
    return NextResponse.json(
      { translated: '', guaranteed: false, error: e.message },
      { headers: cors }
    );
  }
}

export const POST = withApiGuard(handlePost, { maxRequests: 30, prefix: 'translate-consensus' });
