'use client';
import { memo, useState, useEffect } from 'react';
import { FONT } from '../lib/constants.js';
import { useApp } from '../contexts/AppContext.js';
import Icon from './Icon.js';
import PageHeader from './ui/PageHeader.js';
import { leggiGlossario, salvaGlossario } from '../lib/glossario.js';

// ── INIZIO b.89 — questa pagina prometteva e non manteneva ──
// Il glossario e le automazioni vivevano SOLO in useState: aggiungevi un
// termine, uscivi, era sparito. E non c'era nessun tasto per tornare
// indietro. Ora il glossario si salva sul telefono e la pagina dice la
// verita su cosa e gia attivo e cosa e ancora in lavorazione.
// b.95 — un posto solo per leggere e salvare: lib/glossario.js.
// Da questa versione i termini NON restano qui: viaggiano con ogni
// traduzione e comandano la scelta delle parole.
// ── FINE b.89 ──

/**
 * AIView — P4 Schermata 6: AI & Automazioni
 *
 * Central hub for AI-powered features:
 * - Quick suggestions based on recent conversations
 * - Glossary management (custom terms per language pair)
 * - Automation rules (auto-reply, auto-translate, triggers)
 * - Translation style preferences
 * - Interpreter mode shortcut
 */
const AIView = memo(function AIView({
  contacts = [],
  recentConversations = [],
  handleCreateRoom,
  setSelectedMode,
}) {
  const { L, S, theme, setView, prefs } = useApp();
  const [activeSection, setActiveSection] = useState(null);
  // b.89 — parte da quello salvato, non da esempi finti
  const [glossaryTerms, setGlossaryTerms] = useState([]);
  useEffect(() => { setGlossaryTerms(leggiGlossario()); }, []);
  useEffect(() => { salvaGlossario(glossaryTerms); }, [glossaryTerms]);
  const [newTermFrom, setNewTermFrom] = useState('');
  const [newTermTo, setNewTermTo] = useState('');
  // b.139 — nome e descrizione erano italiano fisso dentro lo stato. Sono
  // testi che l'utente legge, non identificatori: qui restano le chiavi e la
  // traduzione avviene al disegno, cosi cambia insieme alla lingua scelta.
  const [automations, setAutomations] = useState([
    { id: 1, name: 'aiGreetName', desc: 'aiGreetDesc', enabled: true },
    { id: 2, name: 'aiSummaryName', desc: 'aiSummaryDesc', enabled: true },
    { id: 3, name: 'aiSpellName', desc: 'aiSpellDesc', enabled: false },
    { id: 4, name: 'aiFormalName', desc: 'aiFormalDesc', enabled: false },
  ]);

  const quickActions = [
    { icona: 'mic', label: L('interpreterWord'), desc: L('interpreterModeDesc'), action: () => { if (setSelectedMode) setSelectedMode('interpreter'); if (handleCreateRoom) handleCreateRoom(); }, color: S.colors.accent1 },
    { icona: 'graduation', label: L('glossaryWord'), desc: L('glossaryManageDesc'), action: () => setActiveSection(activeSection === 'glossary' ? null : 'glossary'), color: S.colors.accent2 },
    { icona: 'zap', label: L('automationsWord'), desc: L('aiAutomationsDesc'), action: () => setActiveSection(activeSection === 'automations' ? null : 'automations'), color: S.colors.statusWarning },
    { icona: 'star', label: L('styleWord'), desc: L('translationPrefsDesc'), action: () => setActiveSection(activeSection === 'style' ? null : 'style'), color: S.colors.accent4 },
  ];

  const translationStyles = [
    { id: 'natural', label: L('styleNatural'), desc: L('styleNaturalDesc'), icon: '' },
    { id: 'literal', label: L('styleLiteral'), desc: L('styleLiteralDesc'), icon: '' },
    { id: 'formal', label: L('styleFormal'), desc: L('styleFormalDesc'), icon: '' },
    { id: 'casual', label: L('styleCasual'), desc: L('styleCasualDesc'), icon: '' },
    { id: 'technical', label: L('styleTechnical'), desc: L('styleTechnicalDesc'), icon: '' },
  ];

  const [selectedStyle, setSelectedStyle] = useState('natural');

  const toggleAutomation = (id) => {
    setAutomations(prev => prev.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
  };

  const addGlossaryTerm = () => {
    if (!newTermFrom.trim() || !newTermTo.trim()) return;
    setGlossaryTerms(prev => [...prev, { from: newTermFrom.trim(), to: newTermTo.trim(), note: '' }]);
    setNewTermFrom('');
    setNewTermTo('');
  };

  return (
    <div style={{
      ...S.page, padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: 16,
      minHeight: '100vh', boxSizing: 'border-box', overflowY: 'auto', paddingBottom: 100,
    }}>
      {/* ── INIZIO b.89 — intestazione con il ritorno a Impostazioni ──
          Prima questa pagina non aveva NESSUN modo di uscire: si restava
          dentro finche non si toccava la barra in basso. */}
      <PageHeader title={L('aiAndGlossary')} onBack={() => setView('settings')} S={S} />
      {/* ── FINE b.89 ── */}
      <div style={{ marginTop: 8 }}>
        <h2 style={{
          color: S.colors.textPrimary, fontSize: 22, fontWeight: 800, margin: 0,
        }}>
          AI e Automazioni
        </h2>
        <p style={{ color: S.colors.textMuted, fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>
          Potenzia le traduzioni con intelligenza artificiale
        </p>
      </div>

      {/* Quick Actions Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
        {quickActions.map((qa, i) => (
          <button key={i} onClick={qa.action}
            style={{
              display: 'flex', flexDirection: 'column', gap: 8, padding: 16,
              borderRadius: 18, cursor: 'pointer', textAlign: 'left',
              background: activeSection === ['glossary', 'automations', 'style'][i - 1]
                ? `${qa.color}15` : S.colors.cardBg,
              border: `1px solid ${activeSection === ['glossary', 'automations', 'style'][i - 1]
                ? `${qa.color}40` : S.colors.cardBorder}`,
              transition: 'all 0.2s', position: 'relative', overflow: 'hidden',
            }}>
            <Icon name={qa.icona} size={26} color={qa.color} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: S.colors.textPrimary }}>{qa.label}</div>
              <div style={{ fontSize: 11, color: S.colors.textMuted, marginTop: 2 }}>{qa.desc}</div>
            </div>
          </button>
        ))}
      </div>

      {/* Glossary Section */}
      {activeSection === 'glossary' && (
        <div style={{
          padding: 16, borderRadius: 18,
          background: S.colors.cardBg, border: `1px solid ${S.colors.accent2Border}`,
          animation: 'vtSlideUp 0.3s ease-out',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ fontSize: 18 }}></span>
            <span style={{ fontSize: 15, fontWeight: 700, color: S.colors.textPrimary }}>{L('personalGlossary')}</span>
            <span style={{
              marginLeft: 'auto', fontSize: 11, padding: '3px 8px', borderRadius: 8,
              background: S.colors.accent2Bg, color: S.colors.accent2, fontWeight: 600,
            }}>
              {glossaryTerms.length} {L('termsCount')}
            </span>
          </div>

          {/* Add new term */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            <input placeholder={L('originalTerm')} value={newTermFrom}
              onChange={e => setNewTermFrom(e.target.value)}
              style={{
                flex: 1, padding: '8px 12px', borderRadius: 10,
                background: S.colors.inputBg, border: `1px solid ${S.colors.inputBorder}`,
                color: S.colors.textPrimary, fontSize: 13, fontFamily: FONT, outline: 'none',
              }} />
            <input placeholder={L('translationWord')} value={newTermTo}
              onChange={e => setNewTermTo(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') addGlossaryTerm(); }}
              style={{
                flex: 1, padding: '8px 12px', borderRadius: 10,
                background: S.colors.inputBg, border: `1px solid ${S.colors.inputBorder}`,
                color: S.colors.textPrimary, fontSize: 13, fontFamily: FONT, outline: 'none',
              }} />
            <button onClick={addGlossaryTerm}
              style={{
                padding: '8px 14px', borderRadius: 10, border: 'none', cursor: 'pointer',
                background: S.colors.btnGradient, color: '#fff', fontSize: 16, fontWeight: 700,
              }}>
              +
            </button>
          </div>

          {/* Terms list */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {glossaryTerms.map((term, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
                borderRadius: 12, background: S.colors.overlayBg,
                border: `1px solid ${S.colors.overlayBorder}`,
              }}>
                <span style={{ fontSize: 13, color: S.colors.textPrimary, fontWeight: 600, flex: 1 }}>{term.from}</span>
                <span style={{ color: S.colors.textMuted, fontSize: 14 }}>→</span>
                <span style={{ fontSize: 13, color: S.colors.accent2, fontWeight: 600, flex: 1 }}>{term.to}</span>
                <button onClick={() => setGlossaryTerms(prev => prev.filter((_, j) => j !== i))}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: S.colors.textMuted, fontSize: 16, padding: '0 4px',
                  }}>×</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Automations Section */}
      {activeSection === 'automations' && (
        <div style={{
          padding: 16, borderRadius: 18,
          background: S.colors.cardBg, border: `1px solid ${S.colors.cardBorder}`,
          animation: 'vtSlideUp 0.3s ease-out',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ fontSize: 18 }}></span>
            <span style={{ fontSize: 15, fontWeight: 700, color: S.colors.textPrimary }}>{L('aiAutomationsTitle')}</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {automations.map(auto => (
              <div key={auto.id} style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px',
                borderRadius: 14, background: S.colors.overlayBg,
                border: `1px solid ${auto.enabled ? S.colors.accent4Border : S.colors.overlayBorder}`,
                transition: 'all 0.2s',
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: S.colors.textPrimary }}>{L(auto.name)}</div>
                  <div style={{ fontSize: 11, color: S.colors.textMuted, marginTop: 2 }}>{L(auto.desc)}</div>
                </div>
                <button onClick={() => toggleAutomation(auto.id)}
                  style={{
                    width: 46, height: 26, borderRadius: 13, border: 'none', cursor: 'pointer',
                    background: auto.enabled ? S.colors.accent4 : S.colors.toggleOff,
                    position: 'relative', transition: 'background 0.3s',
                  }}>
                  <div style={{
                    width: 20, height: 20, borderRadius: '50%', background: '#fff',
                    position: 'absolute', top: 3,
                    left: auto.enabled ? 23 : 3,
                    transition: 'left 0.3s', boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                  }} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Translation Style Section */}
      {activeSection === 'style' && (
        <div style={{
          padding: 16, borderRadius: 18,
          background: S.colors.cardBg, border: `1px solid ${S.colors.cardBorder}`,
          animation: 'vtSlideUp 0.3s ease-out',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ fontSize: 18 }}></span>
            <span style={{ fontSize: 15, fontWeight: 700, color: S.colors.textPrimary }}>{L('translationStyleTitle')}</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {translationStyles.map(style => (
              <button key={style.id} onClick={() => setSelectedStyle(style.id)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px',
                  borderRadius: 14, cursor: 'pointer', textAlign: 'left',
                  background: selectedStyle === style.id ? S.colors.accent1Bg : S.colors.overlayBg,
                  border: `1px solid ${selectedStyle === style.id ? S.colors.accent1Border : S.colors.overlayBorder}`,
                  transition: 'all 0.2s',
                }}>
                <span style={{ fontSize: 22 }}>{style.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: S.colors.textPrimary }}>{style.label}</div>
                  <div style={{ fontSize: 11, color: S.colors.textMuted, marginTop: 1 }}>{style.desc}</div>
                </div>
                {selectedStyle === style.id && (
                  <div style={{
                    width: 20, height: 20, borderRadius: '50%',
                    background: S.colors.btnGradient,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#fff', fontSize: 12, fontWeight: 700,
                  }}>✓</div>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* AI Tips */}
      <div style={{
        padding: 14, borderRadius: 16,
        background: `linear-gradient(135deg, ${S.colors.accent1}08, ${S.colors.accent2}08)`,
        border: `1px solid ${S.colors.accent1Border}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <span style={{ fontSize: 14 }}></span>
          <span style={{ fontSize: 12, fontWeight: 700, color: S.colors.accent1 }}>{L('aiSuggestionLabel')}</span>
        </div>
        <p style={{ color: S.colors.textSecondary, fontSize: 13, lineHeight: 1.5, margin: 0 }}>
          {L('aiTipBody')}
        </p>
      </div>

      {/* Animations */}
      <style>{`
        @keyframes vtSlideUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
});

export default AIView;
