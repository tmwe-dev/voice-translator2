import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
const page = await (await b.newContext({ bypassCSP: true })).newPage();
page.on('pageerror', e => console.log('PAGEERROR:', String(e).slice(0,150)));
await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 });
await page.waitForFunction(() => document.querySelectorAll('button').length > 2, { timeout: 30000 });
const step = async (nome) => { await page.waitForTimeout(1500); console.log('==', nome, '==', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('button')].map(x=>((x.getAttribute('aria-label')||x.innerText||'')).trim().replace(/\n/g,'·').slice(0,22)).filter(Boolean).slice(0,16)))); };
await step('inizio');
try { await page.click('button:has-text("Essential only")', { timeout: 2500 }); } catch {}
try { await page.click('button:has-text("Italia")', { timeout: 4000 }); await page.waitForTimeout(700); await page.click('button:has-text("Continua")'); } catch (e) { console.log('paese:', e.message.slice(0,60)); }
await step('dopo-paese');
try { await page.click('button:has-text("Resta nel browser")', { timeout: 2500 }); } catch {}
try { await page.click('button:has-text("Continua senza account")', { timeout: 4000 }); } catch (e) { console.log('ospite:', e.message.slice(0,60)); }
await step('dopo-ospite');
await b.close();
