# Collaudo completo + fix — Life · Mondo · Profilo · Home (notte)

Lavoro autonomo mentre dormivi. **Nota onesta di metodo (CLAUDE.md):** non posso
pushare io (device_bash non ha rete), quindi il ciclo "riprova DAL VIVO → verde"
sui fix lo chiudi tu al risveglio. Ho quindi: (1) collaudato dal vivo la
**produzione attuale (b.230)**, (2) fatto tre audit del codice, (3) **eseguito i
fix sicuri e coperti da lint+test**, committati in locale pronti al push, e (4)
lasciato a te + collaudo dal vivo i punti che toccano funzioni delicate.

Stato repo: **due commit locali avanti su origin** — `7a6c5b0` (b.231) e
`b5c9797` (b.232). Per mandarli in produzione:

```
cd ~/Downloads/voice-translator2 && git push
```

Prove: **lint 0 errori**; suite **1698 passati / 5 falliti** — i 5 sono
**pre-esistenti e non miei** (debito di `TaxiTalk.js`: emoji + chiavi i18n + il
pattern vietato `L('x')||'testo'`, e una prova di layout). Il conteggio è
**identico** a prima dei fix: zero regressioni introdotte.

---

## 1. Collaudo dal vivo (produzione b.230)

Ho preso il comando del tuo Chrome (come mi hai autorizzato) e percorso Home,
Life (Podcast/Amico/Tavolo/Dossier/Impara/Obiettivi/Compagni), Mondo
(Stanze + News) e Profilo/Impostazioni (tutte le sezioni).

Cosa funziona: l'app carica, Life e i Compagni ci sono (avatar a sfondo
trasparente OK), la chat Amico risponde davvero (endpoint 200 con risposta
reale), le News generano la sintesi, il Profilo mostra tutte le sezioni.

Difetti visti dal vivo:
- **Home**: "Chat di gruppo" mostrava l'**icona auto** identica a TaxiTalk.
- **Home**: refusi di accento nella descrizione ("e una chat", "puo").
- **Load**: in console un **errore React #418 (hydration mismatch)**.
- **Profilo**: "Le tue API Key" mostrava sempre **"Nessuna"**.
- **Profilo**: il toggle **Crittografia E2E** è spento e **ingannevole** (la
  E2E in realtà è sempre attiva nel codice).
- **News**: il fallback immagine di un articolo è un **riquadro vuoto** con una
  letterina appena visibile.
- Incoerenza di nome: **Community** (nav) vs **Il mondo ora** (Home) vs
  **Mondo** (interno) — tre nomi per la stessa cosa.

---

## 2. Bug corretti in b.232 (19 fix, tutti committati)

**Life**
1. `crea()` non resettava `pubblicato`: dopo aver pubblicato un corso il tasto
   "Pubblica" restava bloccato su "✓ Pubblicato" per il corso nuovo.
2. AmicoChat — **race**: se cambiavi Compagno durante l'attesa, la risposta di A
   finiva nella chat di B (e veniva salvata sotto B). Aggiunta guardia + reset
   dell'attesa al cambio Compagno.
3. LifeView — `tutti` ora memoizzato: prima si ricreava a ogni render e
   vanificava il `memo()` dei figli (ri-render continui).
4. LifeView — difesa sulle lezioni della **libreria condivisa** (grezze dal DB):
   `indice`/`obiettivi` mancanti causavano `key` errate e crash su `.length`.
5. Dossier — `L` mancava nelle deps di `passo3` (messaggi d'errore non
   rilocalizzati); aggiunto.
6. Podcast — **Stop lasciava il ciclo appeso**: `parlaTurno` non risolveva la
   promise alla pausa; ora sì.
7. a11y — aria-label ai bottoni solo-icona e agli input di Amico/Tavolo/Dossier.

**Mondo**
8. `topics/riassunto` — la chiamata al fornitore era senza try/catch: un
   rate-limit diventava **500 + allarme Sentry**. Ora è un 502 pulito.
9. SchedaArgomento — la Sintesi ignorava **402/500**: click muto. Ora mostra
   l'errore.
10. MondoView — `!res.ok` (500/429) non era più silenzioso; rimossi `S`/`prefs`
    inutilizzati.
11. MondoNews — `prefs` nelle deps (il nick usato non è più stantìo).
12. MondoDiscussioni — **like idempotente**: prima ogni click faceva +1 in UI
    mentre il DB restava a 1; ora si conta una volta. Colore errore dal tema
    (non più `#ff6b6b` fisso).
13. `discussioni/crea` — rifiuto del **titolo vuoto** (come già fa `commenta`).

**Profilo**
14. SettingsView — "Le tue API Key" ora **conta davvero** le chiavi (prima
    `apiKeyInputs.length` su un oggetto → sempre "Nessuna").
15. CreditsView — `compra()` controlla `r.ok` (niente più click muto da
    sloggato); `usaCodice()` con try/catch.
16. ApiKeysView — stringa "Accedi/Registrati" ora **tradotta**; input chiavi
    `type=password`.
17. HelpView — niente più **contenitori icona vuoti** (spazi/disallineamenti).

**Home**
18. Icona "Chat di gruppo": il rendering è un ternario il cui **default è auto**;
    mancava il ramo `'chat'` → aggiunto (fumetto).
19. Corretti gli accenti in `actRoomDesc` ("è", "può").

---

## 3. Piano di rifactoring — rimasto a te (con motivo)

Non eseguito perché tocca funzioni delicate senza collaudo dal vivo possibile
stanotte, o perché è una **decisione di prodotto**:

- **Toggle Crittografia E2E** (P1 sicurezza): oggi è cosmetico e ingannevole (la
  E2E è sempre attiva in `useWebRTC`). Va deciso col tuo ok: o si **rende
  informativo** ("Sempre attiva", senza interruttore), oppure si cabla davvero.
  Tocca la semantica della sicurezza → non l'ho cambiato alla cieca.
- **Errore React #418 (hydration)** (P1): va indagato con la build non-minified;
  è un mismatch server/client (probabile contenuto dipendente da
  `localStorage`/ora reso senza guardia SSR). Da isolare col collaudo dal vivo.
- **i18n — 47 chiavi Life non tradotte** (P1 per utenti non-IT): tutta la scheda
  **Obiettivi**, il **Debate**, i controlli **avatar** e la **libreria corsi**
  usano `tt('chiave','fallback italiano')`: gli utenti EN/ES/DE le vedono in
  italiano. Vanno aggiunte a **tutti e 15 i pacchetti** (705 voci): lavoro
  meccanico ma da fare con cura sulle traduzioni, non alla cieca.
- **Debito TaxiTalk.js** (i 5 test rossi pre-esistenti): ~30 usi di
  `L('x')||'fallback'`, ~20 chiavi i18n mancanti, un'emoji bandiera, e la chiave
  `lifeGoalsTab` da aggiungere ai 15 pacchetti. È un intervento a sé.
- **Mondo "seguo/seguito"** (P2): il pulsante mostra "Segui" anche per chi
  segui già, perché `profiloPersona` non restituisce il flag. Richiede una
  modifica **backend** (mondoDB) + verifica live.
- **Ritorno pagamento `?ricarica=ok`** (P2): dopo una ricarica riuscita nessuna
  conferma e il parametro resta in URL. Tocca il percorso init/pagamenti →
  meglio con collaudo dal vivo.
- **Unificazione nome Mondo/Community/Il mondo ora** (P2): decisione di prodotto
  su quale nome tenere.
- **Fallback immagine News** e **aria-label del "×"** (P3): il secondo richiede
  una nuova chiave i18n su 15 lingue.

---

## 4. Come procederei al risveglio

1. Tu fai `git push` (manda b.231 + b.232 in produzione).
2. Collaudo dal vivo i fix di b.231+b.232 (libertà che cambia il tono, Omar
   senza fonti, quiz sul contenuto, chat che resta, icona Home, API Key count…).
3. Decidiamo insieme i 3 punti di prodotto (E2E, nomi Mondo, i18n) e li chiudo.
4. Poi la discussione che volevi: cosa permettere a BarTalk dentro PC+Chrome
   contro dentro un telefono (APK/app).
