// ═══════════════════════════════════════════════════════════════
// b.265 — i rilievi del confronto col codice di due giorni fa (b.224).
//
// Richiesto da Luca: «confronta il codice attuale con quello dei deploy
// dell'altro ieri, verifica se trovi altre incongruenze». Nove rilievi
// confermati, tutti corretti in questa versione. Qui c'e la prova che
// ciascuna correzione e nel codice e che non regredisca in silenzio.
// ═══════════════════════════════════════════════════════════════
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { ascoltaVociMute, segnalaVoceMuta } from '../app/lib/segnaleVoce.js';

const RADICE = path.join(__dirname, '..');
const leggi = (p) => fs.readFileSync(path.join(RADICE, p), 'utf8');

// ── A1 · la guardia anti-ricaricamento guarda la vista VERA ──
describe('il service worker nuovo non ricarica la pagina a meta conversazione', () => {
  it('la guardia legge la vista pubblicata, non un hash che nessuno imposta', () => {
    const s = leggi('app/hooks/useInitializeApp.js');
    expect(s).toContain('window.__vtVista');
    expect(s).toMatch(/\/room\|speaker\|taxi\|lobby\|join\|video\/\.test\(vista\)/);
  });
  it('e la pagina la pubblica a ogni cambio di vista', () => {
    expect(leggi('app/page.js')).toMatch(/window\.__vtVista = view;\s*\}, \[view\]\)/);
  });
});

// ── A2 · una voce rimasta muta libera TUTTI E DUE gli strati ──
describe('il messaggio muto si puo riprovare davvero', () => {
  it('il filo fra i due strati funziona: chi segnala sveglia chi ascolta', () => {
    const arrivate = [];
    const stop = ascoltaVociMute((c) => arrivate.push(c));
    segnalaVoceMuta('abc123');
    stop();
    expect(arrivate).toEqual(['abc123']);
  });
  it('un ascoltatore rotto non zittisce gli altri', () => {
    const arrivate = [];
    const stopRotto = ascoltaVociMute(() => { throw new Error('rotto'); });
    const stopSano = ascoltaVociMute((c) => arrivate.push(c));
    segnalaVoceMuta('x');
    stopRotto(); stopSano();
    expect(arrivate).toEqual(['x']);
  });
  it('chi suona segnala nel ramo del fallimento totale', () => {
    const s = leggi('app/hooks/useAudioSystem.js');
    const ramo = s.slice(s.indexOf('suonato === false'));
    expect(ramo).toContain('segnalaVoceMuta(chiave)');
  });
  it('chi filtra libera la chiave col suo prefisso', () => {
    const s = leggi('app/hooks/useRoomPolling.js');
    expect(s).toMatch(/ascoltaVociMute\(\(chiave\) => \{\s*\n?\s*processedForTTSRef\.current\.delete\(`id:\$\{chiave\}`\)/);
  });
});

// ── A3 · il rientro dopo un 401 non e piu un colpo solo per sessione ──
describe('chi resta fuori dalla stanza continua a bussare', () => {
  it('si riprova al secondo rifiuto E poi ogni dieci battiti', () => {
    expect(leggi('app/hooks/useRoomPolling.js'))
      .toContain('auth401CountRef.current === 2 || auth401CountRef.current % 10 === 0');
  });
});

// ── U5 · il menu dei modelli AI si legge come quello delle voci ──
describe('il menu dei modelli AI e opaco e sopra tutto', () => {
  it('velo scuro e pannello con sfondo pieno, z 298/300', () => {
    const s = leggi('app/components/VoiceEngineBar.js');
    const blocco = s.slice(s.indexOf('AI model picker'));
    expect(blocco).toContain('zIndex:298');
    expect(blocco).toContain('zIndex:300');
    expect(blocco).toContain("rgba(0,0,0,0.35)");
    expect(blocco).not.toContain("background:'transparent'");
  });
});

// ── U6 · l'obiettivo del Dossier vale per UNA apertura del Tavolo ──
describe('il Tavolo non ripropone obiettivi di discussioni vecchie', () => {
  it('lasciando la scheda tavolo, l\'obiettivo passato si azzera', () => {
    expect(leggi('app/components/Life/LifeView.js'))
      .toMatch(/if \(scheda !== 'tavolo' && debateObiettivo\) setDebateObiettivo\(''\)/);
  });
});

// ── U1+U3 · le chiavi Life esistono nei pacchetti pieni ──
describe('la sezione Life parla la lingua dell\'interfaccia', () => {
  const PIENI = ['it','en','es','fr','de','pt','zh','ja','ko','th','ar','hi','ru','tr','vi','nl','pl','sv','da','cs','ro','hu'];
  const CAMPIONE = ['lifeDebateStart','lifeDebateSynthesis','lifeGoalNew','lifeGoalSave',
    'lifeListen','lifeCoursesAvailable','lifeQuizAll','lifeAvatarErr','lifeSurprise',
    'lifeSayAloud','lifeRecStart','lifeRecMicPerm','lifeProfConversational','lifeProfOperative'];
  for (const l of PIENI) {
    it(`${l}: le chiavi Life ci sono`, () => {
      const s = leggi(`app/lib/locales/${l}.js`);
      for (const k of CAMPIONE) expect(s, `${l} manca ${k}`).toContain(`"${k}"`);
    });
  }
  it('i 22 pacchetti pieni hanno TUTTI le stesse chiavi (parita totale)', async () => {
    const it_ = (await import('../app/lib/locales/it.js')).default;
    for (const l of PIENI) {
      const m = (await import(`../app/lib/locales/${l}.js`)).default;
      const mancano = Object.keys(it_).filter((k) => !(k in m));
      expect(mancano, `${l} manca: ${mancano.slice(0, 5)}`).toEqual([]);
      expect(Object.keys(m).length).toBe(Object.keys(it_).length);
    }
  });
});

// ── U2 · il pannello pronuncia non parla piu solo italiano ──
describe('il pannello pronuncia usa le chiavi di traduzione', () => {
  it('ogni testo visibile passa da tt(), col ripiego italiano', () => {
    const s = leggi('app/components/Life/PannelloPronuncia.js');
    for (const k of ['lifeSayAloud','lifeRecStart','lifeRecStop','lifeRecListening',
      'lifeRecRetry','lifeRecNothing','lifeRecFailed','lifeRecMicPerm','lifeRecHeard']) {
      expect(s).toContain(`tt('${k}'`);
    }
    // e riceve L da chi lo monta
    expect(leggi('app/components/Life/LifeView.js')).toMatch(/<PannelloPronuncia[^>]*L=\{L\}/);
  });
});

// ── U4 · le etichette del Deep Setting si traducono ──
describe('superfici e profili del Deep Setting non sono piu cablati in italiano', () => {
  it('le superfici riusano le chiavi delle schede', () => {
    const s = leggi('app/components/Life/GestioneCompagni.js');
    expect(s).toContain("tt('lifeFriendTab', 'Amico')");
    expect(s).toContain("tt('lifePodcast', 'Podcast')");
  });
  it('i profili passano dalla mappa delle chiavi', () => {
    const s = leggi('app/components/Life/GestioneCompagni.js');
    expect(s).toContain('CHIAVI_PROFILO');
    expect(s).toContain("conversazionale: 'lifeProfConversational'");
  });
});

// ── il buco pre-esistente scoperto strada facendo ──
describe('BUG PRE-ESISTENTE (b.262): l\'olandese era rimasto senza avviso audio', () => {
  it('nl ha audioBlockedTapScreen come gli altri 21', () => {
    expect(leggi('app/lib/locales/nl.js')).toContain('"audioBlockedTapScreen"');
  });
});
