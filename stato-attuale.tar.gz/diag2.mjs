import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
const page = await (await b.newContext({ bypassCSP: true })).newPage();
await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 });
await page.waitForFunction(() => document.querySelectorAll('button').length > 2, { timeout: 30000 });
try { await page.click('button:has-text("Essential only")', { timeout: 2500 }); } catch {}
// il primo schermo ORA e la lista paesi lunga: clicca la voce Italia esatta
await page.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => (x.innerText||'').includes('Italia') && !(x.innerText||'').includes('Italiano·Ita')) || [...document.querySelectorAll('button')].find(x => (x.innerText||'').startsWith('🇮🇹')); if (b) b.click(); });
await page.waitForTimeout(1200);
console.log('dopo italia:', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('button')].map(x=>(x.innerText||'').trim().replace(/\n/g,'·').slice(0,22)).filter(Boolean).slice(0,12))));
try { await page.click('button:has-text("Continua")', { timeout: 3000 }); } catch (e) { console.log('continua ko'); }
await page.waitForTimeout(1500);
try { await page.click('button:has-text("Resta nel browser")', { timeout: 2500 }); } catch {}
try { await page.click('button:has-text("Continua senza account")', { timeout: 4000 }); } catch { console.log('ospite ko'); }
await page.waitForTimeout(1500);
for (let i = 0; i < 14; i++) {
  const st = await page.evaluate(() => ({
    bott: [...document.querySelectorAll('button')].map(x=>((x.getAttribute('aria-label')||x.innerText||'')).trim().replace(/\n/g,'·').slice(0,24)).filter(Boolean).slice(0,14),
    inp: [...document.querySelectorAll('input')].map(x=>x.placeholder||x.type),
    home: [...document.querySelectorAll('button')].some(b => (b.innerText||'').includes('Invita una persona')),
  }));
  console.log('giro', i, JSON.stringify(st));
  if (st.home) break;
  await page.evaluate(() => {
    const q = (t) => [...document.querySelectorAll('button')].find(x => ((x.getAttribute('aria-label')||'') + (x.innerText||'')).includes(t));
    const inp = [...document.querySelectorAll('input')].find(x => /Marco|chiami/i.test(x.placeholder||''));
    if (inp && !inp.value) { const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set; s.call(inp,'Anna'); inp.dispatchEvent(new Event('input',{bubbles:true})); return 'nome'; }
    const av = q('Marcus'); if (av) av.click();
    const via = q('Inizia ad usare BarTalk'); if (via && !via.disabled) { via.click(); return 'inizia'; }
    for (const t of ['Avanti','Salta']) { const b=q(t); if (b && !b.disabled) { b.click(); return t; } }
  });
  await page.waitForTimeout(1400);
}
await b.close();
