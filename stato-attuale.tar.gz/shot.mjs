import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const p = await b.newPage({ viewport: { width: 560, height: 380 } });
const errs=[];
p.on('console', m=>{ if(m.type()==='error') errs.push(m.text()); });
await p.goto('http://localhost:8099/test-mappa.html', {waitUntil:'load'});
let ready=false, err=null, hasMap=null;
for(let i=0;i<40;i++){
  const r = await p.evaluate(()=>({ok:window.__MAP_READY===true, err:window.__MAP_ERR||null, has:window.__HAS_MAP}));
  hasMap=r.has;
  if(r.ok){ready=true;break;}
  if(r.err){err=r.err;break;}
  await p.waitForTimeout(500);
}
await p.waitForTimeout(2500);
await p.screenshot({ path: 'prova-mappa.png' });
console.log('HAS_MAP(typeof Map):', hasMap, '| MAP_READY:', ready, '| MAP_ERR:', err);
console.log('consoleErrors:', errs.slice(0,4));
await b.close();
