import { chromium } from 'playwright';
const logs = [];
const browser = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const ctx = await browser.newContext({ bypassCSP: true });
const page = await ctx.newPage();
page.on('console', m => logs.push('['+m.type()+'] '+m.text().slice(0,140)));
page.on('pageerror', e => logs.push('[pageerror] '+ (e.message||e).slice(0,140)));
try { await page.goto('http://localhost:3111/', { waitUntil:'domcontentloaded', timeout: 90000 }); } catch(e){ logs.push('[goto] '+e.message); }
await page.waitForTimeout(6000);
await browser.close();
console.log(logs.map((l,i)=>(i+1)+'. '+l).join('\n'));
console.log('HYDRATION ERRORS:', logs.filter(l=>/hydrat|418|did not match|server rendered/i.test(l)).length);
