// b.261 — prova dal vivo: il pannello voci e opaco, sopra i messaggi, e filtra.
import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
const page = await (await b.newContext({ bypassCSP: true })).newPage();
await page.goto('http://localhost:3210/', { waitUntil: 'domcontentloaded', timeout: 60000 });
await page.waitForFunction(() => document.querySelectorAll('button').length > 2, { timeout: 30000 });
try { await page.click('button:has-text("Essential only")', { timeout: 2500 }); } catch {}
try { await page.evaluate(() => { const x = [...document.querySelectorAll('button')].find(y => (y.innerText||'').startsWith('🇮🇹')); if (x) x.click(); }); await page.waitForTimeout(800); await page.click('button:has-text("Continua")', { timeout: 3000 }); await page.waitForTimeout(1500); } catch {}
try { await page.click('button:has-text("Resta nel browser")', { timeout: 2500 }); } catch {}
try { await page.click('button:has-text("Continua senza account")', { timeout: 4000 }); await page.waitForTimeout(1800); } catch {}
for (let g = 0; g < 12; g++) {
  if (await page.evaluate(() => [...document.querySelectorAll('button')].some(x => (x.innerText||'').includes('Invita una persona')))) break;
  await page.evaluate(() => {
    const q = (t) => [...document.querySelectorAll('button')].find(x => ((x.getAttribute('aria-label')||'') + (x.innerText||'')).includes(t));
    const inp = [...document.querySelectorAll('input')].find(x => /Marco|chiami/i.test(x.placeholder||''));
    if (inp && !inp.value) { const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set; s.call(inp,'Collaudo'); inp.dispatchEvent(new Event('input',{bubbles:true})); return; }
    const av = q('Marcus'); if (av) av.click();
    const via = q('Inizia ad usare BarTalk'); if (via && !via.disabled) { via.click(); return; }
    for (const t of ['Avanti','Salta']) { const z = q(t); if (z && !z.disabled) { z.click(); return; } }
  });
  await page.waitForTimeout(1200);
}
for (let i = 0; i < 5; i++) { await page.waitForTimeout(500); if (!await page.evaluate(() => !!document.querySelector('[role=dialog]'))) break; await page.keyboard.press('Escape'); }
// entra in una stanza (Invita una persona -> Entra nella stanza)
await page.evaluate(() => { [...document.querySelectorAll('button')].find(x => (x.innerText||'').includes('Invita una persona')).click(); });
await page.waitForTimeout(2500);
await page.evaluate(() => { const b2 = [...document.querySelectorAll('button')].find(x => /Entra nella stanza/i.test(x.innerText||'')); if (b2) b2.click(); });
await page.waitForTimeout(2500);
// manda un messaggio cosi c'e una bolla dietro il pannello
await page.evaluate(() => { const i = [...document.querySelectorAll('input,textarea')].find(x => /scrivi|messag/i.test(x.placeholder||'')); if (i) { const s = Object.getOwnPropertyDescriptor((i.tagName==='TEXTAREA'?window.HTMLTextAreaElement:window.HTMLInputElement).prototype,'value').set; s.call(i,'Ciao'); i.dispatchEvent(new Event('input',{bubbles:true})); } });
await page.keyboard.press('Enter');
await page.waitForTimeout(2500);
// apri il selettore voce (la barra motore in alto: primo bottone della barra)
const apri = await page.evaluate(() => { const b2 = [...document.querySelectorAll('button')].find(x => /Edge TTS|ElevenLabs|OpenAI|Female|Male|♀|♂/i.test(x.innerText||'')); if (!b2) return null; b2.click(); return b2.innerText; });
console.log('aperto selettore da:', JSON.stringify(apri));
await page.waitForTimeout(1200);
await page.screenshot({ path: '/tmp/voci-pannello.png' });
console.log('input filtro presente:', await page.evaluate(() => !!document.querySelector('input[aria-label]')));
await b.close();
