import { chromium } from 'playwright';
const logs = [];
const browser = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const context = await browser.newContext({ bypassCSP: true });
const page = await context.newPage();
page.on('console', m => logs.push('['+m.type()+'] '+m.text()));
page.on('pageerror', e => logs.push('[pageerror] '+ (e.message||e)));
try { await page.goto('http://localhost:3111/', { waitUntil:'domcontentloaded', timeout: 90000 }); }
catch(e){ logs.push('[goto] '+e.message); }
await page.waitForTimeout(7000);
const bodyText = (await page.evaluate(()=>document.body?.innerText||'').catch(()=>'')).slice(0,120);
await browser.close();
console.log('bodyText:', JSON.stringify(bodyText));
const rel = logs.filter(l => /hydrat|did not match|server rendered|mismatch|A tree|attribute|text content|nesting|expected server|418|only.*client|cannot be a (child|descendant)/i.test(l));
console.log('=== RILEVANTI ('+rel.length+') di '+logs.length+' ===');
console.log(rel.slice(0,10).join('\n========\n'));
